/*
*	Copyright (C) 2005 Chai Braudo (braudo@users.sourceforge.net)
*
*	This file is part of Jooleem - http://sourceforge.net/projects/jooleem
*
*   Jooleem is free software; you can redistribute it and/or modify
*   it under the terms of the GNU General Public License as published by
*   the Free Software Foundation; either version 2 of the License, or
*   (at your option) any later version.
*
*   Jooleem is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU General Public License for more details.
*
*   You should have received a copy of the GNU General Public License
*   along with Jooleem; if not, write to the Free Software
*   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

// The game board.

#ifndef _BOARD_H_
#define _BOARD_H_

#include <SDL.h>
#include <vector>
#include "../common/common.h"

class Selection;

using namespace std;

class Board
{
	private:
		COLOR m_marbles[BOARD_SIZE][BOARD_SIZE];			// The board's contents
		SDL_Surface *m_normalSurfaces[NUM_OF_COLORS];	// Normal marbles' surfaces
		SDL_Surface *m_selectedSurfaces[NUM_OF_COLORS];	// Selected marbles' surfaces
		SDL_Surface *m_pausedSurface;					// Surface for greyed out marble

		// Marbl flash:
		bool m_flashing;								// Are we currently flashing
		COLOR m_flashColor;								// Color of flashing rectangle
		Uint32 m_flashStart;							// Time flashing started
		Coordinate m_flashCoord1, m_flashCoord2;		// Flashing rectangle coordinates

	public:	
		Board();
		~Board();

		void Populate(int x0, int y0, int x1, int y1);	// Populates a section of the board with random marbles

		COLOR GetMarbleColor(int x, int y);				// Returns the color of a marble
		COLOR GetMarbleColor(Coordinate coord);

		void Flash(COLOR color, Coordinate coord1, Coordinate coord2);	// Flash a rectangle

		int GetRectangles(vector<vector<Coordinate> > *a_opCoordVect, int num = -1); // Returns a vector of N valid rects
		bool GetRectangle(Selection* selection);		// Returns a valid rectangle
		bool ContainsRectangle();						// Does the board contain a valid rectangle?

		bool Update();									// Update (for flashing)

		// Converts between marble coordinates and its screen location, in pixels:
		static void CoordToPixels(Coordinate *coord1, Coordinate *coord2,
			Uint16 *x1, Uint16 *y1, Uint16 *x2, Uint16 *y2);
		static void PixelsToCoord(Coordinate *coord1, Coordinate *coord2,
			Uint16 *x1, Uint16 *y1, Uint16 *x2, Uint16 *y2);
		static void CoordToSDLRect(Coordinate *coord1, Coordinate *coord2, SDL_Rect *rect);

		void Draw(SDL_Surface *screen, Selection *selection, bool paused = false);	// Draws the board

	private:
		static const int FLASH_DURATION = 300;		// Duration of rectangle flash sequnece, in ms
		static const int FLASH_COUNT = 3;			// Number of flashes in a flash sequence
};

#endif

