/*
*	Copyright (C) 2005 Chai Braudo (braudo@users.sourceforge.net)
*
*	This file is part of Jooleem - http://sourceforge.net/projects/jooleem
*
*   Jooleem is free software; you can redistribute it and/or modify
*   it under the terms of the GNU General Public License as published by
*   the Free Software Foundation; either version 2 of the License, or
*   (at your option) any later version.
*
*   Jooleem is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU General Public License for more details.
*
*   You should have received a copy of the GNU General Public License
*   along with Jooleem; if not, write to the Free Software
*   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "../game/board.h"
#include <SDL_image.h>
#include <cstdlib>
#include <ctime>
#include <iostream>

#include "../game/selection.h"
#include "../common/surfacemanager.h"
#include "../common/events.h"

using namespace std;


// Constructor
Board::Board()
{
	m_flashStart = 0;

	// Init the PRNG:
	srand((unsigned)time(NULL));

	// Load the marble surfaces:
	SurfaceManager* surfaceMgr = SurfaceManager::GetInstance();

	m_normalSurfaces[BLUE] = surfaceMgr->GetSurface("MarbleNormalBlue");
	m_normalSurfaces[GREEN] = surfaceMgr->GetSurface("MarbleNormalGreen");
	m_normalSurfaces[RED] = surfaceMgr->GetSurface("MarbleNormalRed");
	m_normalSurfaces[YELLOW] = surfaceMgr->GetSurface("MarbleNormalYellow");

	m_selectedSurfaces[BLUE] = surfaceMgr->GetSurface("MarbleSelectedBlue");
	m_selectedSurfaces[GREEN] = surfaceMgr->GetSurface("MarbleSelectedGreen");
	m_selectedSurfaces[RED] = surfaceMgr->GetSurface("MarbleSelectedRed");
	m_selectedSurfaces[YELLOW] = surfaceMgr->GetSurface("MarbleSelectedYellow");

	m_pausedSurface = surfaceMgr->GetSurface("MarblePaused");

	// Populate the board:
	do
	{
		Populate(0, 0, BOARD_SIZE - 1, BOARD_SIZE - 1);
	} while (!ContainsRectangle());
}


// Destructor - free resources
Board::~Board()
{
	
}


// Returns the color of a marble:
COLOR Board::GetMarbleColor(int x, int y)
{	
	// Sanity check:
	if (x < 0 || y < 0 || x >= BOARD_SIZE || y >= BOARD_SIZE)
		return NUM_OF_COLORS;

	return m_marbles[x][y];
}


// Returns a marble's color:
COLOR Board::GetMarbleColor(Coordinate coord)
{
	return GetMarbleColor(coord.x, coord.y);
}


// Flash a rectangle.
void Board::Flash(COLOR color, Coordinate coord1, Coordinate coord2)
{
	m_flashing = true;
	m_flashColor = color;
	m_flashCoord1 = coord1;
	m_flashCoord2 = coord2;
	m_flashStart = SDL_GetTicks();

	// Force redraw:
	PushUserEvent(EVENT_REDRAW);
}

// Fills the argument vector of vectors of coordinates with the 
// coordinates of up to num valid rectangles.
// The method returns the number of valid rectangles found.
// If a_opCoordVect is NULL, the rectangles are just counted.
// If num is 0 or less, the method processes all of the
// board's rectangles.
int Board::GetRectangles(vector<vector<Coordinate> > *a_opCoordVect, int num)
{
	a_opCoordVect->clear();

	Coordinate l_oCoord;
	int l_iCount = 0;

	for (int i = 0 ; i < BOARD_SIZE - 1 ; i++)
		for (int j = 0 ; j < BOARD_SIZE - 1 ; j++)
		{
			COLOR l_eColor = m_marbles[i][j];
			
			// Keep moving to the right, until a marble of the same color is found.
			int X = -1;
			for (int k = j + 1 ; k < BOARD_SIZE ; k++)
				if (m_marbles[i][k] == l_eColor)
				{
					X = k;
					break;
				}

			// If no match found, continue with next marble.
			if (X == -1)
				continue;

			// Keep moving down, until a marble of the same color is found.
			int Y = -1;
			for (int k = i + 1 ; k < BOARD_SIZE ; k++)
				if (m_marbles[k][j] == l_eColor)
				{
					Y = k;
					break;
				}

			// If no match found, continue with next marble.
			if (Y == -1)
				continue;

			// Check the fourth marble:
			if (m_marbles[Y][X] == l_eColor)
			{
				
				if (a_opCoordVect != NULL)
				{
					vector<Coordinate> l_oRect;

					l_oCoord.x = i ; l_oCoord.y = j;
					l_oRect.push_back(l_oCoord);

					l_oCoord.x = Y ; l_oCoord.y = j;
					l_oRect.push_back(l_oCoord);

					l_oCoord.x = i ; l_oCoord.y = X;
					l_oRect.push_back(l_oCoord);

					l_oCoord.x = Y ; l_oCoord.y = X;
					l_oRect.push_back(l_oCoord);

					a_opCoordVect->push_back(l_oRect);
				}
				
				l_iCount++;
				if (num > 0 && (int) l_iCount == num)
						return l_iCount;
			}
		}

	return l_iCount;

}

// Gets a valid rectangle.
// Returns false if no rectangle found.
bool Board::GetRectangle(Selection* selection)
{
	if (selection != NULL)
		selection->Clear();

	for (int i = 0 ; i < BOARD_SIZE - 1 ; i++)
		for (int j = 0 ; j < BOARD_SIZE - 1 ; j++)
		{
			COLOR l_eColor = m_marbles[i][j];
			
			// Keep moving to the right, until a marble of the same color is found.
			int X = -1;
			for (int k = j + 1 ; k < BOARD_SIZE ; k++)
				if (m_marbles[i][k] == l_eColor)
				{
					X = k;
					break;
				}

			// If no match found, continue with next marble.
			if (X == -1)
				continue;

			// Keep moving down, until a marble of the same color is found.
			int Y = -1;
			for (int k = i + 1 ; k < BOARD_SIZE ; k++)
				if (m_marbles[k][j] == l_eColor)
				{
					Y = k;
					break;
				}

			// If no match found, continue with next marble.
			if (Y == -1)
				continue;

			// Check the fourth marble:
			if (m_marbles[Y][X] == l_eColor)
			{
				// Populate the selection:
				if (selection != NULL)
				{
					selection->Add(i, j, this);
					selection->Add(Y, j, this);
					selection->Add(i, X, this);
					selection->Add(Y, X, this);
				}

				return true;
			}
		}

	// If we are here, no match was found.
	return false;
}

// Does the board contain a rectangle?
bool Board::ContainsRectangle()
{
	return GetRectangle(NULL);
}

// Update the board.
// If the board is flashing, push a redraw event.
bool Board::Update()
{
	Uint32 flashElapsed = SDL_GetTicks() - m_flashStart;	// Time elapsed since last flash
	bool redraw = false;

	// Determine the flashing status:
	if (flashElapsed < FLASH_DURATION && ((flashElapsed / (FLASH_DURATION / FLASH_COUNT)) % 2) == 0) // Flashing
	{
		if (!m_flashing) // ... but was not flashing before
			redraw = true;

		m_flashing = true;
	}
	else // Not flashing
	{
		if (m_flashing) // ... but was flashing before
			redraw = true;

		m_flashing = false;
	}

	return redraw;
}


// Converts a rectangle's board coordinates to its location on screen, in pixels.
void Board::CoordToPixels(Coordinate *coord1, Coordinate *coord2,
			Uint16 *x1, Uint16 *y1, Uint16 *x2, Uint16 *y2)
{
	if (coord1 == NULL || coord2 == NULL || x1 == NULL || x2 == NULL || y1 == NULL || y2 == NULL)
		return;

	// Upper left corner:
	*x1 = BOARD_X + coord1->x * MARBLE_IMAGE_SIZE;
	*y1 = BOARD_Y + coord1->y * MARBLE_IMAGE_SIZE;

	// Lower right corner:
	*x2 = BOARD_X + (coord2->x + 1) * MARBLE_IMAGE_SIZE;
	*y2 = BOARD_Y + (coord2->y + 1) * MARBLE_IMAGE_SIZE;
}


// Converts a rectangle's screen location, in pixels, to its board coordinates.
void Board::PixelsToCoord(Coordinate *coord1, Coordinate *coord2,
			Uint16 *x1, Uint16 *y1, Uint16 *x2, Uint16 *y2)
{
	if (coord1 == NULL || coord2 == NULL || x1 == NULL || x2 == NULL || y1 == NULL || y2 == NULL)
		return;

	// Upper left corner:
	coord1->x = (*x1 - BOARD_X) / MARBLE_IMAGE_SIZE;
	coord1->y = (*y1 - BOARD_Y) / MARBLE_IMAGE_SIZE;

	// Lower right corner:
	coord2->x = (*x2 - BOARD_X) / MARBLE_IMAGE_SIZE;
	coord2->y = (*y2 - BOARD_Y) / MARBLE_IMAGE_SIZE;
}


// Converts a rectangle's board coordinates to its location on screen, in pixels.
// The result is stored in an SDL_Rect structure.
void Board::CoordToSDLRect(Coordinate *coord1, Coordinate *coord2, SDL_Rect *rect)
{
	if (coord1 == NULL || coord2 == NULL)
		return;

	Uint16 x1, y1, x2, y2;

	CoordToPixels(coord1, coord2, &x1, &y1, &x2, &y2);

	rect->x = x1;
	rect->y = y1;
	rect->w = x2 - x1;
	rect->h = y2 - y1;
}


// Draws the board to screen:
void Board::Draw(SDL_Surface *screen, Selection *selection, bool paused)
{
	SDL_Rect l_oRect = {0, 0, 0, 0};
	Uint32 flashElapsed = SDL_GetTicks() - m_flashStart;	// Time elapsed since last flash

	for (int i = 0 ; i < BOARD_SIZE ; i++)
		for (int j = 0 ; j < BOARD_SIZE ; j++)
		{

			l_oRect.x = (Sint16) (BOARD_X + i * MARBLE_IMAGE_SIZE - (m_normalSurfaces[0]->w - MARBLE_IMAGE_SIZE) / 2); 
			l_oRect.y = (Sint16) (BOARD_Y + j * MARBLE_IMAGE_SIZE - (m_normalSurfaces[0]->h - MARBLE_IMAGE_SIZE) / 2);

			if (paused)	// Use greyed out marbles
				SDL_BlitSurface(m_pausedSurface, NULL, screen, &l_oRect);
			else
			{
				// Flash:
				if (flashElapsed < FLASH_DURATION
					&& m_flashCoord1.x <= i && m_flashCoord2.x >= i
					&& m_flashCoord1.y <= j && m_flashCoord2.y >= j)
				{
					if (!m_flashing)
						SDL_BlitSurface(m_normalSurfaces[m_flashColor], NULL, screen, &l_oRect);
					else
						SDL_BlitSurface(m_selectedSurfaces[m_flashColor], NULL, screen, &l_oRect);
				}

				// Selected:
				else if (selection->IsSelected(i, j))	// Marbl is selected
					SDL_BlitSurface(m_selectedSurfaces[m_marbles[i][j]], NULL, screen, &l_oRect);

				// Normal:
				else	
					SDL_BlitSurface(m_normalSurfaces[m_marbles[i][j]], NULL, screen, &l_oRect);
			}
		}			
}

// Populates a section of the board with random marbles:
void Board::Populate(int x0, int y0, int x1, int y1)
{
	// Sanity check:
	if (x0 < 0 || y0 < 0 || x1 >= BOARD_SIZE || y1 >= BOARD_SIZE 
		|| x0 >= x1 || y0 >= y1)
		return;

	for (int i = x0 ; i <= x1 ; i++)
		for (int j = y0 ; j <= y1 ; j++)
			m_marbles[i][j] = static_cast<COLOR>(rand() % (NUM_OF_MARBLE_COLORS));
}

