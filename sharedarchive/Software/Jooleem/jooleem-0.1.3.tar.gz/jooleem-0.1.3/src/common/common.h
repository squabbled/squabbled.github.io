/*
*	Copyright (C) 2005 Chai Braudo (braudo@users.sourceforge.net)
*
*	This file is part of Jooleem - http://sourceforge.net/projects/jooleem
*
*   Jooleem is free software; you can redistribute it and/or modify
*   it under the terms of the GNU General Public License as published by
*   the Free Software Foundation; either version 2 of the License, or
*   (at your option) any later version.
*
*   Jooleem is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU General Public License for more details.
*
*   You should have received a copy of the GNU General Public License
*   along with Jooleem; if not, write to the Free Software
*   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef _COMMON_H_
#define _COMMON_H_

#include "SDL.h"

#include <string>
using namespace std;

// Application name, version and website:
static const string APP_NAME = "Jooleem";
static const string APP_VERSION = "0.1.3 (20050827)";
static const string APP_URL = "http://jooleem.sourceforge.net";

// Screen dimensions:
static const int SCREEN_WIDTH = 640;
static const int SCREEN_HEIGHT = 480;

static bool FULLSCREEN = false;			// True = fullscreen, false = windowed

static const string CAPTION = "Jooleem";						// Window caption
static const string ICON = "data/interface/icon.png";		// Window icon

// Marbl coordinate:
typedef struct
{
	int x;
	int y;
} Coordinate;

static const int BOARD_SIZE = 10;		// Game board size, in marbles. The board is square.

static const Uint16 BORDER_SIZE = 8;	// Size of window border, in pixels

enum COLOR {BLUE, GREEN, RED, YELLOW, GREY, BLACK, WHITE, NUM_OF_COLORS};	// Marbl colors
static const int NUM_OF_MARBLE_COLORS = GREY - BLUE;
										

// Size of a marble image (in pixels):
static const Uint16 MARBLE_IMAGE_SIZE = 44;

// Calculate the board's origin:
static Uint16 BOARD_X = SCREEN_WIDTH - BOARD_SIZE * MARBLE_IMAGE_SIZE - BORDER_SIZE; // = 192
static Uint16 BOARD_Y = BORDER_SIZE; // = 8

#endif
