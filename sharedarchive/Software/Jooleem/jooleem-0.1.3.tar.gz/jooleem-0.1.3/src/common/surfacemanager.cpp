/*
*	Copyright (C) 2005 Chai Braudo (braudo@users.sourceforge.net)
*
*	This file is part of Jooleem - http://sourceforge.net/projects/jooleem
*
*   Jooleem is free software; you can redistribute it and/or modify
*   it under the terms of the GNU General Public License as published by
*   the Free Software Foundation; either version 2 of the License, or
*   (at your option) any later version.
*
*   Jooleem is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU General Public License for more details.
*
*   You should have received a copy of the GNU General Public License
*   along with Jooleem; if not, write to the Free Software
*   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "../common/surfacemanager.h"
#include "../common/trap.h"
#include "SDL_image.h"

SurfaceManager* SurfaceManager::m_instance = NULL;

// Returns an m_instance of the class. If no m_instance exists, the method 
// creates a new one.
SurfaceManager* SurfaceManager::GetInstance()
{
	if (m_instance == NULL)
	{
		try
		{
			m_instance = new SurfaceManager();
		}
		catch (std::bad_alloc)
		{
			ERR("SurfaceManager::GetInstance() - Error allocating m_instance"); 
		}
	}

	return m_instance;
}


// Adds a new surface to the manager.
// If a resource with the same ID already exists, a pointer
// to it is returned. Otherwise, the method returns a pointer
// to the new surface.
SDL_Surface* SurfaceManager::AddSurface(string ID, string fileName)
{
	// Check whether the ID already exists in the map:
	map<string, SDL_Surface*>::iterator itr = m_map.find(ID);
	if (itr != m_map.end())
		itr->second;

	// Load the image:
	SDL_Surface *surface = IMG_Load(fileName.c_str());
	
	TRAP(surface == NULL, "SurfaceManager::AddSurface() - Could not open " << fileName); 

	// Convert it to the framebuffer's display format:
	SDL_Surface *converted = SDL_DisplayFormatAlpha(surface);
	SDL_FreeSurface(surface);

	m_map[ID] = converted;

	return converted;
}


// Adds a new surface to the manager.
// If a resource with the same ID exists, it is overwritten.
// The method returns a pointer to the new surface.
SDL_Surface* SurfaceManager::AddSurface(string ID, SDL_Surface *surface)
{
	// Check whether the ID already exists in the map:
	map<string, SDL_Surface*>::iterator itr = m_map.find(ID);
	if (itr != m_map.end())
		SDL_FreeSurface(itr->second);
	
	TRAP(surface == NULL, "SurfaceManager::AddSurface() - adding an NULL surface"); 

	m_map[ID] = surface;

	return surface;
}


// Gets a surface by its ID.
// If the ID does not exist, NULL is returned.
SDL_Surface *SurfaceManager::GetSurface(string ID)
{
	map<string, SDL_Surface*>::iterator itr = m_map.find(ID);
	if (itr == m_map.end())
		return NULL;

	return itr->second;
}
		

// Releases all the loaded surfaces.
void SurfaceManager::Cleanup()
{
	map<string, SDL_Surface*>::iterator itr;
	for (itr = m_map.begin() ; itr != m_map.end() ; itr++)
		SDL_FreeSurface(itr->second);
	
	m_map.clear();
}

